import json
import re
from datetime import datetime, timezone
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/140.0 Safari/537.36"
    )
}

SOURCES = {
    "darik": "https://dariknews.bg/",
    "dsport": "https://dsport.bg/",
}

session = requests.Session()
session.headers.update(HEADERS)


def clean(text):
    return re.sub(r"\s+", " ", text or "").strip()


def get_html(url):
    response = session.get(url, timeout=20)
    response.raise_for_status()
    response.encoding = response.apparent_encoding or response.encoding
    return response.text


def is_article_url(url, source):
    if not url or not url.startswith(("http://", "https://")):
        return False

    low = url.lower()

    if source == "darik":
        # Darik article URLs normally contain /novini/...
        return "/novini/" in low or "/regioni/" in low

    if source == "dsport":
        # Dsport articles use /football/... , /basketball/... etc.
        blocked = (
            "/category/", "/tag/", "/author/", "/video/",
            "/gallery/", "/search", "/page/"
        )
        if any(x in low for x in blocked):
            return False
        return "dsport.bg/" in low and low.rstrip("/") != "https://dsport.bg"

    return False


def extract_articles(html, base_url, source):
    soup = BeautifulSoup(html, "html.parser")
    found = []
    seen = set()

    # Look at article containers first, then fall back to all links.
    containers = soup.find_all(["article", "h1", "h2", "h3", "h4"])
    links = []

    for container in containers:
        if container.name == "article":
            links.extend(container.find_all("a", href=True))
        else:
            a = container.find("a", href=True)
            if a:
                links.append(a)

    links.extend(soup.find_all("a", href=True))

    for a in links:
        href = urljoin(base_url, a.get("href", "").strip())
        if not is_article_url(href, source):
            continue

        title = clean(
            a.get_text(" ", strip=True)
            or a.get("title", "")
            or a.get("aria-label", "")
        )

        if len(title) < 25 or len(title) > 300:
            continue

        key = href.split("#")[0].rstrip("/")
        if key in seen:
            continue

        # Ignore obvious navigation/category labels.
        bad_words = [
            "начало", "меню", "контакти", "за нас", "още",
            "виж всички", "виж повече", "абонирай се"
        ]
        if title.lower() in bad_words:
            continue

        seen.add(key)
        found.append({
            "title": title,
            "url": href,
            "time": ""
        })

        if len(found) >= 20:
            break

    return found


def get_source(source, url):
    try:
        html = get_html(url)
        items = extract_articles(html, url, source)
        return items
    except Exception as exc:
        print(f"{source}: {exc}")
        return []


def main():
    darik = get_source("darik", SOURCES["darik"])
    dsport = get_source("dsport", SOURCES["dsport"])

    data = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "darik": darik[:20],
        "dsport": dsport[:20],
    }

    with open("news.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"Darik: {len(darik)}")
    print(f"Dsport: {len(dsport)}")
    print("news.json updated successfully")


if __name__ == "__main__":
    main()
